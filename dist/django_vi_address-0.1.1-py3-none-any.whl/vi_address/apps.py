from django.apps import AppConfig


class ViAddressConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vi_address'
